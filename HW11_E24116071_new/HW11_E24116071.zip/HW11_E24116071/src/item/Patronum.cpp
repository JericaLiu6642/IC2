#include <iostream>
#include "Patronum.h"
using namespace std;

Patronum::Patronum()
	:ArmorItem(5, "Patronum", "Defense + 30", "A kind of Anti-Dementor, a guardian which acts as a shield between you and the Dementor.", 0, 'a', 30)
{

}