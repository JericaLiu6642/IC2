#pragma once
#ifndef SWORD_H
#define SWORD_H
#include <string>
#include"WeaponItem.h"

class Sword : public WeaponItem
{
public:
	Sword();
};

#endif // !AXE_H
