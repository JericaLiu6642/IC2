#pragma once
#ifndef CLOAK_H
#define CLOAK_H

#include <iostream>
#include <string>
#include "ArmorItem.h"
using namespace std;

class Cloak : public ArmorItem
{
public:
	Cloak();
};
#endif
