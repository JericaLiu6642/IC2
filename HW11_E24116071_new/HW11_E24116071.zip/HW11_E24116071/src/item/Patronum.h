#pragma once
#ifndef PATRONUM_H
#define PATRONUM_H
#include <string>
#include "ArmorItem.h"
using namespace std;

class Patronum : public ArmorItem
{
public:
	Patronum();
};
#endif
